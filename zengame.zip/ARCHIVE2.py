import pygame, sys, time, random
from pygame.locals import *


                            


def init():         #Sets up border rects and other basic shitake mushrooms
    
#Variables
    global IMAGEDICT, WINWIDTH, WINHEIGHT, FPS, DISPLAYSURF, FPSCLOCK, BASICFONT, SPAWN
    SPAWN = [0,0]
    WINWIDTH  = 400 
    WINHEIGHT = 300
    assert (WINWIDTH)%100 == 0 and (WINHEIGHT)%100 == 0, "Window dimensions(width and height) invalid: must be multiples of 100"
    FPS = 10 # frames per second settingisplay.set_caption('Zengane the waste of breath')
#color, clock and font
#Displaysurf init
    pygame.init()   
    DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
    pygame.display.set_caption('Zengane the waste of breath')
#color, clock and font
    DISPLAYSURF.fill((200,200,200))#fill screen white
    FPSCLOCK = pygame.time.Clock()
    #BASICFONT = pygame.font.Font('freesansbold.ttf', 18)

#Image import and rect creation
    IMAGEDICT ={'drey':{"idle" : pygame.image.load('/home/pi/Desktop/sprite1/Sprites/drey.gif'),
                        "walkright" : pygame.image.load('/home/pi/Desktop/sprite1/Sprites/WR.gif'),
                        "walkleft"  : pygame.image.load('/home/pi/Desktop/sprite1/Sprites/WL.gif')},
             "plains": {"1" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/GrassBlock.gif"),\
                        "2" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/GrassSlopeL.gif"),\
                        "3" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/GrassSlopeR.gif") ,\
                        "4" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/DirtBlock.gif") ,\
                        "5" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/DirtSlopeL.gif") ,\
                        "6" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/DirtSlopeR.gif")},
             "caves" : {"1" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneBlock.gif") ,\
                        "2" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneSlopeL.gif") ,\
                        "3" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneSlopeR.gif") ,\
                        "4" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneTopBlock.gif") ,\
                        "5" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneTopSlopeL.gif") ,\
                        "6" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneTopSlopeR.gif")},
         "misc":{"DoorClosed":pygame.image.load("/home/pi/Desktop/sprite1/misc/DoorClosed.gif"),
                   "DoorOpen":pygame.image.load("/home/pi/Desktop/sprite1/misc/DoorOpen.gif"),
                      "key" : pygame.image.load("/home/pi/Desktop/sprite1/misc/key.gif")},
                "enemy" : {"eyeR":pygame.image.load("/home/pi/Desktop/sprite1/Sprites/eye.gif"),
                           "eyeL":pygame.transform.flip(pygame.image.load("/home/pi/Desktop/sprite1/Sprites/eye.gif"),True,False)}

                }

def BackGround(lvl):
    y=0
    with open("/home/pi/Desktop/txt.txt") as t:
        dest = False
        rectarray = []
        enemyarray = []
        for line in t:
            x=0
            if "$" in line and dest == True:
                break
            if dest == True:
                for chara in line:
                    offsety = 0
                    if chara == "1" and level[0] != "caves":
                        offsety = 4
                    if chara == "\n":
                        break
                    if chara == "*":
                        SPAWN = [x*20,y*20]
                    if chara == "I":
                        eye = Enemy(IMAGEDICT["enemy"]["eyeR"],[x*20,y*20])
                        enemyarray.append(eye)
                    if chara == "   " or chara == "n":
                        x+=1
                        continue#(x*20+SCROLL[0],y*20-offsety+SCROLL[1])
                    if chara == "K":
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT["misc"]["key"], (x*20,y*20-offsety)),IMAGEDICT["misc"]["key"]])
                    if chara == "D":
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT["misc"]["DoorClosed"], (x*20,y*20-offsety)),IMAGEDICT["misc"]["DoorClosed"]])
                    if chara not in IMAGEDICT[level[0]]:
                        pygame.draw.rect(DISPLAYSURF, (0,200,200),((x*20),(y*20),8,8))
                    else:
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT[level[0]][chara], (x*20,y*20-offsety)),IMAGEDICT[level[0]][chara]])
                    #pygame.display.update()
                    x+=1
                y+=1
            if "$" in line:
                level = line.rpartition("$")
                if lvl == level[2].strip("\n") or lvl == int(level[2].strip("\n")):
                    dest = True
        return rectarray, SPAWN, enemyarray
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def collisionDetect(PlayerRect, scroll, rectarray=[], speed=[]):
    
    collarray = []
    key = False
    door = False
    grounded = False
    for rect in rectarray:
        rect[0].x+=scroll[0]
        collarray.append(rect[0])
    PlayerRect.x+=speed[0]
    #print(collarray)
    #collide = {"top": False, "bottom": False, "right": False, "left": False}
    index = PlayerRect.collidelist(collarray)
    if index != -1:
        if rectarray[index][1] == IMAGEDICT["misc"]["DoorClosed"]:
            door = True
            print("door"+str(index))
        if rectarray[index][1] == IMAGEDICT["misc"]["key"]:
            key = True
            print("key"+str(index))
        if speed[0]>0:#PlayerRect.right > collarray[index].left:
            PlayerRect.right = collarray[index].left
        if speed[0]<0:#PlayerRect.left < collarray[index].right:
            PlayerRect.x = collarray[index].right
    index = PlayerRect.collidelist(collarray)
    if index != -1:
        pass
    PlayerRect.y+=speed[1]
    index = PlayerRect.collidelist(collarray)
    if index != -1:
        if rectarray[index][1] == IMAGEDICT["misc"]["DoorClosed"]:
            door = True
            print("door"+str(index))
        if rectarray[index][1] == IMAGEDICT["misc"]["key"]:
            key = True
            print("key"+str(index))
        if speed[1]>=0:#PlayerRect.bottom > collarray[index].top:
            grounded = True
        if speed[1]<0:#PlayerRect.top < collarray[index].bottom:
            PlayerRect.y = collarray[index].bottom
        
            
##    collarray = []
##    for rect in rectarray:
##        collarray.append(rect[0])
        
    if door:
        return PlayerRect,speed,2
    if key:
        return PlayerRect,speed,3,index
    if grounded:
        PlayerRect.bottom = collarray[index].top
        speed[1]=0
        return PlayerRect,speed,1
    return PlayerRect,speed,0
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def walk(skin):
    if skin == IMAGEDICT['drey']['walkleft'] or skin == IMAGEDICT['drey']['idle']:
        return IMAGEDICT['drey']['walkright']
    elif skin == IMAGEDICT['drey']['walkright']:
        return IMAGEDICT['drey']['walkleft']
    else:
        return IMAGEDICT['drey']['idle']
def redraw(PlayerRect, scroll, RectArray,speed,slack = 100):
    
    Rect = []
    DISPLAYSURF.fill((200,200,200))
    if True:
        #print(PlayerRect.centerx - (scroll[0]+WINWIDTH/2))
        #print(PlayerRect.centerx - (scroll[0]+(WINWIDTH/2)))
        if PlayerRect.centerx <scroll[0]+slack and scroll[0]>=0:#######SCROLL LEFT#####
            scroll[0] = -1*speed[0]
            PlayerRect.centerx = scroll[0]+slack
##            if PlayerRect.centerx <scroll[0]+slack+20:
##                scroll[0] = PlayerRect.centerx - slack
        elif PlayerRect.centerx > scroll[0]+WINWIDTH-slack and scroll[0]<WINWIDTH-slack:#######SCROLL RIGHT#######
            scroll[0] = -1*speed[0]
            PlayerRect.centerx = scroll[0]+WINWIDTH-slack
##            if PlayerRect.centerx > scroll[0]+WINWIDTH-slack-20:
##                scroll[0] = PlayerRect.centerx-WINWIDTH+slack
        else:
            scroll[0] = 0 
        if abs(PlayerRect.centerx - (scroll[0]+(WINWIDTH/2)))<slack:
            pass
    for surf in RectArray:
        DISPLAYSURF.blit(surf[1],(surf[0].x+scroll[0],surf[0].y))
    return scroll, PlayerRect
    
def __main__():
    
    init()
    level = 1
    L = BackGround(level)
    RectArray = L[0]
    enemyarray = L[2]
    skin = IMAGEDICT['drey']['idle']
    PlayerRect = DISPLAYSURF.blit(skin,L[1])
    #SCROLL = scroll(PlayerRect,[0,0])
    pressedLeft = False
    pressedRight = False
    pressedDown = False
    grounded = False
    grav = 4
    PlayerSpeed = [0,0]
    SCROLL = [0,0]
    inventory = []
    
    while True: # main game loop
        q = redraw(PlayerRect,SCROLL,RectArray,PlayerSpeed)
        SCROLL = q[0]
        PlayerRect = q[1]
        #print(PlayerRect.x)

            
        for event in pygame.event.get(): # event handling loop
            if event.type == QUIT:
                print("Thanks For Playing!")
                pygame.quit()
                sys.exit()
                
            elif event.type == KEYDOWN:
                if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                    PlayerSpeed[0]=-4
                    pressedLeft = True
                elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                    PlayerSpeed[0]=4
                    pressedRight = True
                elif (event.key == K_UP or event.key == K_w):
                    grav = 4
                    if grounded == True:
                        PlayerSpeed[1] = -32
                elif (event.key == K_DOWN or event.key == K_s):
                    PlayerSpeed[1]+=4
                    pressedDown = True
                elif (event.key == K_r):
                    PlayerRect = DISPLAYSURF.blit(skin,SPAWN)
                    PlayerSpeed[0] = 0
                    PlayerSpeed[1] = 0
                    SCROLL = [0,0]
                    RectArray = BackGround(level)

                    
            elif event.type == KEYUP:
                if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                    pressedLeft = False
                    if pressedRight == False:
                        PlayerSpeed[0]=0
                    else:
                        PlayerSpeed[0]=4
                elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                    pressedRight = False
                    if pressedLeft == False:
                        PlayerSpeed[0]=0
                    else:
                        PlayerSpeed[0]=-4
                elif (event.key == K_UP or event.key == K_w):
                    grav = 8
                elif (event.key == K_DOWN or event.key == K_s):
                    pressedDown = False
                    catspeepY=0
            elif event.type == MOUSEBUTTONDOWN:
                    click = pygame.mouse.get_pos()
                    PlayerRect.x = click[0]
                    PlayerRect.y = click[1]


        #Collision detection and Bounce
        if PlayerSpeed[1] < 16:
            PlayerSpeed[1]+=grav #gravity
        #PlayerRect.x+=PlayerSpeed[0]
        #PlayerRect.y+=PlayerSpeed[1]
        doot = collisionDetect(PlayerRect,SCROLL,RectArray,[PlayerSpeed[0],PlayerSpeed[1]])
        PlayerRect = doot[0]
        PlayerSpeed = doot[1]
        if doot[2] == 1:
            grounded = True
        elif doot[2] == 2 and "k" in inventory:
            inventory.remove("k")
            level+=1
            L = BackGround(level)
            RectArray = L[0]
            PlayerRect.x = L[1][0]
            PlayerRect.y = L[1][1]
            
        elif doot[2] == 3:
            if RectArray[doot[3]][1] == IMAGEDICT["misc"]["key"]:
                inventory.append("k")
                RectArray.pop(doot[3])
                
            #RectArray = redraw(PlayerRect,[0,0],RectArray)
            #
        else:
            grounded = False
        if PlayerSpeed[0] != 0:
            skin = walk(skin)
        if PlayerSpeed[1] != 0:
            pass

        counter = 0
        for enemy in enemyarray:
            enemyrect = enemy.move(RectArray, PlayerRect,SCROLL)
            if enemyrect.colliderect(PlayerRect):
                enemy.zoom([PlayerRect.x,PlayerRect.y])
##                if(enemy.grapple(pygame.transform.scale2x(skin))):
##                    enemyarray.pop(counter)
            counter+=1

        
        PlayerRect = DISPLAYSURF.blit(skin,(PlayerRect.x,PlayerRect.y))
        pygame.display.update()
        FPSCLOCK.tick(FPS)

###########################################################################
###########################################################################

class Enemy():
    def __init__(self,skin, spawn = [0,0], pattern = 0):
        if not skin:
            self.skin = IMAGEDICT["enemy"]["eyeR"]
        else:
            self.skin = skin
        self.pos = spawn
        self.pattern = pattern
        self.movement = [0,0]
        self.grab = False
        self.rect = DISPLAYSURF.blit(self.skin, self.pos)
        #other setup
    def move(self,rectarray, PlayerRect,scroll):
        self.grab = False
        if self.pattern == 0:
            pass
        elif self.pattern == 1:
            pass
        elif self.pattern == 2:
            pass
        elif self.pattern == 3:
            pass
        elif self.pattern == 4:
            pass
        elif self.pattern == 5:
            pass
        else:
            pass
        adjustedpos = [0,0]
        adjustedpos[0] = self.pos[0]+scroll[0]
        adjustedpos[1] = self.pos[1]+scroll[1]
        self.rect = DISPLAYSURF.blit(self.skin, adjustedpos)
        return self.rect#, grab
    def zoom(self,center):
        newsurf = pygame.display.get_surface()
        newsurf = pygame.transform.scale2x(newsurf)
        x = center[0]-WINWIDTH/4
        y = center[1]-WINHEIGHT/4
        rec = DISPLAYSURF.blit(newsurf,(x,y))
        #print(rec)
    def grapple(self,PlayerSkin):
        if PlayerSkin == IMAGEDICT["drey"]["idle"] or PlayerSkin == IMAGEDICT["drey"]["walkright"] or PlayerSkin == IMAGEDICT["drey"]["walkleft"]:
            form = 0
        else:
            form = 0
        #zoom in and play the grapple animation/minigame
        #create loop outside of mainloop
        grapplebar = 0
        timelimit = 30
        timer = 0
        match = 0
        while grapplebar<100 or timer<timelimit:
            #print(timer,grapplebar)
            if timer>= timelimit/2:
                pass#play phase 2 grapple
            else:
                pass#play phase 1 grapple
            if match == 0:
                prompt = random.choice(["up","down","left","right"])
                print(prompt)#will later display prompt
                match = 1
            elif match == 1:
                for event in pygame.event.get(): # event handling loop
                    if event.type == KEYDOWN:
                        if (event.key == K_LEFT and prompt == "left" or event.key == K_a and prompt == "left"):
                            match = 2#and probably other stuf to up the grapplemeter
                            grapplebar+=10#and provide other feedback
                        if (event.key == K_RIGHT and prompt == "right" or event.key == K_d and prompt == "right"):
                            match = 2
                            grapplebar+=10
                        if (event.key == K_DOWN and prompt == "down" or event.key == K_s and prompt == "down"):
                            match = 2
                            grapplebar+=10
                        if (event.key == K_UP and prompt == "up" or event.key == K_w and prompt == "up"):
                            match = 2
                            grapplebar+=10
            
            elif match == 2:
                print("correct")
                FPSCLOCK.tick(2)
                match = 0
            timer+=1
            FPSCLOCK.tick(6)
                
        if grapplebar>=100:
            return True#won encounter
        else:
            return False#lost encounter


############################################################################
############################################################################


__main__()
#try:
#    __main__()
#except:
#    print("Thanks For Playing!")
#    pygame.quit()
#    sys.exit()
    
            
