import pygame
def BackGround(lvl, IMAGEDICT, DISPLAYSURF):
    
    y=0
    with open("/home/pi/Desktop/Zengane/txt.txt") as t:
        dest = False
        rectarray = []
        enemyarray = []
        print(IMAGEDICT["plains"]["1"].get_width())
        stdSize = IMAGEDICT["plains"]["1"].get_width()
        for line in t:
            x=0
            if "$" in line and dest == True:
                break
            if dest == True:
                for chara in line:
                    offsety = 0
                    if chara == "\n":
                        break
                    if chara == "*":
                        SPAWN = [x*stdSize,y*stdSize]
                    if chara == "I":
                        eye = [x*stdSize,y*stdSize]
                        enemyarray.append(eye)
                    if chara == "   " or chara == "n":
                        x+=1
                        continue
                    if chara == "K":
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT["misc"]["key"], (x*stdSize,y*stdSize)),IMAGEDICT["misc"]["key"]])
                    if chara == "D":
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT["misc"]["DoorClosed"], (x*stdSize,y*stdSize)),IMAGEDICT["misc"]["DoorClosed"]])
                    if chara not in IMAGEDICT[level[0]]:
                        pygame.draw.rect(DISPLAYSURF, (0,200,200),((x*stdSize),(y*stdSize),8,8))
                    else:
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT[level[0]][chara], (x*stdSize,y*stdSize)),IMAGEDICT[level[0]][chara]])
                    x+=1
                y+=1
            if "$" in line:
                level = line.rpartition("$")
                if lvl == level[2].strip("\n") or lvl == int(level[2].strip("\n")):
                    dest = True
        return rectarray, SPAWN, enemyarray
