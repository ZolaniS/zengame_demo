import pygame, sys, time, random
from BackGroundFunc import BackGround
from EnemyClass import Enemy
from pygame.locals import *


                            


def init():         #Sets up border rects and other basic shitake mushrooms
    
#Global variables
    global IMAGEDICT, WINWIDTH, WINHEIGHT, FPS, DISPLAYSURF, FPSCLOCK, BASICFONT, SPAWN, DILATION
    WINWIDTH  = 480*2
    WINHEIGHT = int(WINWIDTH*3/4)
    DILATION = int(2)#scales up size of assets to match 
    assert (WINWIDTH)%120 == 0, "Window dimensions(width and height) invalid: must be multiples of 100"
    FPS = 10 # frames per second setting
    SPAWN = [0,0]
#color, clock and font
#Displaysurf init
    pygame.init()   
    DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
    pygame.display.set_caption('Zengane the waste of breath')
#color, clock and font
    DISPLAYSURF.fill((200,200,200))#fill screen grey
    FPSCLOCK = pygame.time.Clock()
    #BASICFONT = pygame.font.Font('freesansbold.ttf', 18)

#Image import
    IMAGEDICT={'drey':{"idle":pygame.image.load('/home/pi/Desktop/Zengane/sprite1/Sprites/drey.gif'),
                "walkright" : pygame.image.load('/home/pi/Desktop/Zengane/sprite1/Sprites/WR.gif'),
                "walkleft"  : pygame.image.load('/home/pi/Desktop/Zengane/sprite1/Sprites/WL.gif')},
             "plains": {"1" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/GrassBlock.gif"),
                        "2" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/GrassSlopeL.gif"),
                        "3" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/GrassSlopeR.gif") ,
                        "4" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/DirtBlock.gif") ,
                        "5" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/DirtSlopeL.gif") ,
                        "6" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/DirtSlopeR.gif")},
             "caves" : {"1" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/StoneBlock.gif") ,
                        "2" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/StoneSlopeL.gif") ,
                        "3" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/StoneSlopeR.gif") ,
                        "4" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/StoneTopBlock.gif") ,
                        "5" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/StoneTopSlopeL.gif") ,
                        "6" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Blocks/StoneTopSlopeR.gif")},
         "misc":{"DoorClosed":pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/DoorClosed.gif"),
                   "DoorOpen":pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/DoorOpen.gif"),
                      "key" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/key.gif"),
                    "CueUp" : pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue1.gif"),
                    "CueUp!": pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue2.gif"),
                  "CueDown" : pygame.transform.rotate(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue1.gif"),180),
                  "CueDown!": pygame.transform.rotate(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue2.gif"),180),
                  "CueLeft" : pygame.transform.rotate(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue1.gif"),90),
                  "CueLeft!": pygame.transform.rotate(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue2.gif"),90),
                 "CueRight" : pygame.transform.rotate(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue1.gif"),270),
                 "CueRight!": pygame.transform.rotate(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/misc/cue2.gif"),270)},
            "enemy" : {"eyeR":pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Sprites/eye.gif"),
                       "eyeL":pygame.transform.flip(pygame.image.load("/home/pi/Desktop/Zengane/sprite1/Sprites/eye.gif"),True,False)}

                }
    #Apply dilation to all images
    for imageType in IMAGEDICT:
        for image in IMAGEDICT[imageType]:
            IMAGEDICT[imageType][image] = pygame.transform.scale(IMAGEDICT[imageType][image],(IMAGEDICT[imageType][image].get_width()*DILATION,IMAGEDICT[imageType][image].get_height()*DILATION))

##def BackGround(lvl):

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def collisionDetect(PlayerRect, scroll, rectarray=[], speed=[], IMAGEDICT = {}):
    
    collarray = []
    returnType = "default"
    for rect in rectarray:#isolates the rectangles in rectarray(from BackGroundFunc)
        rect[0].x+=scroll[0]
##        rect[0].x = rect[0].x/DILATION
##        rect[0].y = rect[0].y/DILATION
##        rect[0].w = rect[0].w/DILATION
##        rect[0].h = rect[0].h/DILATION
        collarray.append(rect[0])
        
    PlayerRect.x+=speed[0]#Apply horizontal movement, and check for collisions
    index = PlayerRect.collidelist(collarray)
    if index != -1:

        if rectarray[index][1] == IMAGEDICT["misc"]["key"]:#1st priority key check
            returnType = "key"
            print("key"+str(index))
        elif rectarray[index][1] == IMAGEDICT["misc"]["DoorClosed"]:#2nd priority door check
            returnType = "door"
            print("door"+str(index))
        elif PlayerRect.colliderect(collarray[index]):#final priority normal blocks
            if speed[0]>=0:#//PlayerRect.right > collarray[index].left://
                PlayerRect.right = collarray[index].left
            elif speed[0]<0:#//PlayerRect.left < collarray[index].right://
                PlayerRect.left = collarray[index].right


    PlayerRect.y+=speed[1]#Apply Vertical movement and check for collisions
    index = PlayerRect.collidelist(collarray)
    if index != -1:

        if rectarray[index][1] == IMAGEDICT["misc"]["key"]:#1st priority key check
            returnType = "key"
            print("key"+str(index))
            
        elif rectarray[index][1] == IMAGEDICT["misc"]["DoorClosed"]:#2nd priority door
            returnType = "door"
            print("door"+str(index))
            
        elif PlayerRect.colliderect(collarray[index]):#final priority normal blocks
            if speed[1]>=0:#//PlayerRect.bottom > collarray[index].top://
                returnType = "grounded"
                PlayerRect.bottom = collarray[index].top
            elif speed[1]<0:#//PlayerRect.top < collarray[index].bottom://
                PlayerRect.top = collarray[index].bottom

                
    #index = PlayerRect.collidelist(collarray)#if still stuck
    #if index != -1:
        #pass#apply a stuck countdown and tp to last safe space
    
    return PlayerRect,speed,returnType,index
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def walk(skin):#checks current step of walk cycle and returns logical next step.
    if skin == IMAGEDICT['drey']['walkleft'] or skin == IMAGEDICT['drey']['idle']:
        return IMAGEDICT['drey']['walkright']
    elif skin == IMAGEDICT['drey']['walkright']:
        return IMAGEDICT['drey']['walkleft']
    else:
        return IMAGEDICT['drey']['idle']
def redraw(PlayerRect, scroll, RectArray,speed,slack = 100):
    
    Rect = []
    DISPLAYSURF.fill((200,200,200))##############################BACKGROUND##BACKGROUND##BACKGROUND####
    if True:
        if PlayerRect.centerx <scroll[0]+slack and scroll[0]>=0:#######SCROLL LEFT#####
            scroll[0] = -1*speed[0]
            #//PlayerRect.centerx = scroll[0]+slack//
        elif PlayerRect.centerx > scroll[0]+WINWIDTH-slack and scroll[0]<WINWIDTH-slack:#######SCROLL RIGHT#######
            scroll[0] = -1*speed[0]
            #//PlayerRect.centerx = scroll[0]+WINWIDTH-slack//
        else:
            scroll[0] = 0
    for surf in RectArray:#redraw all map and apply dilation and scroll
        DISPLAYSURF.blit(surf[1],((surf[0].x+scroll[0]) ,(surf[0].y)) )
    return scroll, PlayerRect


def parseInput(PlayerRect,PlayerSpeed,grounded, pressed):
    exitType = 0
    for event in pygame.event.get(): # event handling loop
        if event.type == QUIT:#graceful quit
            print("Thanks For Playing!")
            pygame.quit()
            sys.exit()
            
        elif event.type == KEYDOWN:
            if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                PlayerSpeed[0]=-4#move left
                pressed["left"] = True
            elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                PlayerSpeed[0]=4#move right
                pressed["right"] = True
            elif (event.key == K_UP or event.key == K_w):
                grav = 4## FIX JUMP ## FIX JUMP ## FIX JUMP ## FIX JUMP ## FIX JUMP ##
                pressed["up"] = True#note: add coyote time and parabolic jumping
                if grounded == True:
                    PlayerSpeed[1] = -32
            elif (event.key == K_DOWN or event.key == K_s):
                PlayerSpeed[1]+=4
                pressed["down"] = True
            elif (event.key == K_r):
                exitType = 1

                
        elif event.type == KEYUP:
            if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                pressed["left"] = False
                if pressed["right"] == False:
                    PlayerSpeed[0]=0#graceful direction switching
                else:
                    PlayerSpeed[0]=4
            elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                pressed["right"] = False
                if pressed["left"] == False:
                    PlayerSpeed[0]=0#graceful direction switching
                else:
                    PlayerSpeed[0]=-4
            elif (event.key == K_UP or event.key == K_w):
                pressed["up"] = False#reapply normal gravity
                grav = 8
            elif (event.key == K_DOWN or event.key == K_s):
                pressed["down"] = False#stand-in for interaction/crouch
                
        elif event.type == MOUSEBUTTONDOWN:#tp to click hack## remove later ## remove later ## remove later ##
            exitType = 2
            click = pygame.mouse.get_pos()
                
    if exitType == 0:#default exit type
        return exitType, pressed, PlayerSpeed
    if exitType == 1:#restart exit type
        return exitType, "useless second return"
    if exitType == 2:#hack exit type
        return exitType, click
        
def __main__():
    
    init()#var setup
    level = 1
    enemyarray = []
    L = BackGround(level, IMAGEDICT, DISPLAYSURF)#create background return list of rect/image lists
    RectArray = L[0]
    skin = IMAGEDICT['drey']['idle']
    PlayerRect = DISPLAYSURF.blit(skin,DILATION*L[1])#create player rect
    pressed = {"left": False, "right": False, "up": False, "down": False}
    grounded = False
    grav = 4
    PlayerSpeed = [0,0]
    SCROLL = [0,0]
    inventory = []
    for enemy in L[2]:#creates enemies from positions in L[2]
        enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT['enemy']['eyeR'],enemy)
        enemyarray.append(enemy)
    
    while True: # main game loop
        q = redraw(PlayerRect,SCROLL,RectArray,PlayerSpeed)#redraws background efficiently
        #SCROLL = q[0]
        #PlayerRect = q[1]

        

        exitType = parseInput(PlayerRect, PlayerSpeed, grounded, pressed)
        if exitType[0] == 0:#normal exit type
            pressed = exitType[1]
            PlayerSpeed = exitType[2]
        elif exitType[0] == 1:#restart exit type ####BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##
            L = BackGround(level, IMAGEDICT, DISPLAYSURF)
            RectArray = L[0]
            enemyarray = L[2]
            PlayerRect.x = L[1][0]
            PlayerRect.y = L[1][1]
            PlayerSpeed = [0,0]
            for enemy in L[2]:
                enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT['enemy']['eyeR'],enemy)
                enemyarray.append(enemy)## ERROR ## ERROR ## ERROR ## ERROR ###first enemy ignored###
        elif exitType[0] == 2:#click hack exit type
            PlayerRect.x = exitType[1][0]
            PlayerRect.y = exitType[1][1]
        else:
            print("bunked up")#oof
        


        if PlayerSpeed[1] < 16:#infinite gravity limiter
            PlayerSpeed[1]+=grav #gravity
        
        col = collisionDetect(PlayerRect,SCROLL,RectArray,[PlayerSpeed[0],PlayerSpeed[1]],IMAGEDICT)
        PlayerRect = col[0]
        PlayerSpeed = col[1]

        if col[2] == "key":#collect key exit, 1st priority
            print(RectArray[col[3]][1])
            if RectArray[col[3]][1] == IMAGEDICT["misc"]["key"]:
                inventory.append("k")
                RectArray.pop(col[3])
        
        elif col[2] == "door" and "k" in inventory:#open door exit, 2nd priority, creates next level
            inventory.remove("k")
            level+=1
            L = BackGround(level, IMAGEDICT, DISPLAYSURF)
            RectArray = L[0]
            enemyarray = L[2]
            PlayerRect.x = L[1][0]
            PlayerRect.y = L[1][1]
            
        elif col[2] == "grounded":#grounded exit, third priority
            grounded = True
                
        else:#no special case exit
            grounded = False
        if PlayerSpeed[0] != 0:
            skin = walk(skin)
        if PlayerSpeed[1] != 0:
            pass

        counter = 0
        for enemy in enemyarray:#moves and checks for grapple in each enemy
            enemyrect = enemy.move(RectArray, PlayerRect,SCROLL)#moves and checks for grapple on each enemy
            if enemyrect.colliderect(PlayerRect):#if enemy hits player
                enemy.zoom([PlayerRect.x,PlayerRect.y],pygame.display.get_surface())#broken zoom##BUG##BUG##BUG##broken zoom
                if(enemy.grapple(pygame.transform.scale2x(skin))):#if player wins grapple
                    enemyarray.pop(counter)#kill enemy
            counter+=1

        
        PlayerRect = DISPLAYSURF.blit(skin,(PlayerRect.x,PlayerRect.y))#draw character
        pygame.display.update()#update screen
        FPSCLOCK.tick(FPS)


##class Enemy():



__main__()
#try:
#    __main__()
#except:
#    print("Thanks For Playing!")
#    pygame.quit()
#    sys.exit()
    
            
