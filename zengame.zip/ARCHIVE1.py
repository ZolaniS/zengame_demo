import pygame, sys, time
from pygame.locals import *


def init():         #Sets up border rects and other basic shitake mushrooms
    
#Variables
    global IMAGEDICT, WINWIDTH, WINHEIGHT, FPS, DISPLAYSURF, FPSCLOCK, BASICFONT, TILEMAP
    WINWIDTH  = 400 
    WINHEIGHT = 300
    assert (WINWIDTH)%100 == 0 and (WINHEIGHT)%100 == 0, "Window dimensions(width and height) invalid: must be multiples of 100"
    FPS = 10 # frames per second setting
#Displaysurf init
    pygame.init()   
    DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
    pygame.display.set_caption('Zengane the waste of breath')
#color, clock and font
    DISPLAYSURF.fill((200,200,200))#fill screen white
    FPSCLOCK = pygame.time.Clock()
    #BASICFONT = pygame.font.Font('freesansbold.ttf', 18)

#Image import and rect creation
    IMAGEDICT = {'catgirl'  : pygame.image.load('/home/pi/Desktop/python_games/catgirl2.gif'),
             "plains": {"1" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/GrassBlock.gif"),\
                        "2" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/GrassSlopeL.gif"),\
                        "3" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/GrassSlopeR.gif") ,\
                        "4" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/DirtBlock.gif") ,\
                        "5" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/DirtSlopeL.gif") ,\
                        "6" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/DirtSlopeR.gif")},#
             "caves" : {"1" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneBlock.gif") ,\
                        "2" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneSlopeL.gif") ,\
                        "3" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneSlopeR.gif") ,\
                        "4" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneTopBlock.gif") ,\
                        "5" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneTopSlopeL.gif") ,\
                        "6" : pygame.image.load("/home/pi/Desktop/sprite1/Blocks/StoneTopSlopeR.gif")}
                }

def BackGround(lvl):
    y=0
    with open("/home/pi/Desktop/txt.txt") as t:
        dest = False
        rectarray = []
        for line in t:
            x=0
            if "$" in line and dest == True:
                break
            if dest == True:
                for chara in line:
                    offsety = 0
                    if chara == "1" and level[0] != "caves":
                        offsety = 4
                    if chara == "\n":
                        break
                    if chara == "   " or chara == "n":
                        x+=1
                        continue
                    if chara not in IMAGEDICT[level[0]]:
                        pygame.draw.rect(DISPLAYSURF, (0,200,200),((x*20),(y*20),8,8))
                    else:
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT[level[0]][chara], (x*20,y*20-offsety)),IMAGEDICT[level[0]][chara]])
                    pygame.display.update()
                    x+=1
                y+=1
            if "$" in line:
                level = line.rpartition("$")
                if lvl == level[2].strip("\n") or lvl == int(level[2].strip("\n")):
                    dest = True
        return rectarray
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def collisionDetect(Xpos=0,Ypos=0, Width=10, Height=10):
    if Xpos < 0:
        return True, "Left"
    if(Xpos+Width) > (WINWIDTH):
        return True, "Right"
    if Ypos < 0:
        return True, "Top"
    if(Ypos+Height) > (WINHEIGHT):
        return True, "Bottom"
    return False, "useless second return"
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        

    
def __main__():
    
    init()
    RectArray = BackGround(1)
    catrect = DISPLAYSURF.blit(IMAGEDICT['catgirl'],(0,0))
    pressedLeft = False
    pressedRight = False
    pressedDown = False
    grounded = False
    grav = 4
    catspeedX = 0
    catspeedY = 0
    
    while True: # main game loop
        
        #BackGround(1)
        DISPLAYSURF.fill((200,200,200))
        for surf in RectArray:
            DISPLAYSURF.blit(surf[1],(surf[0].x,surf[0].y))
            
        for event in pygame.event.get(): # event handling loop
            if event.type == QUIT:
                print("Thanks For Playing!")
                pygame.quit()
                sys.exit()
                
            elif event.type == KEYDOWN:
                if (event.key == K_LEFT and catrect.x>=0 or event.key == K_a and catrect.x>=0):
                    catspeedX=-4
                    pressedLeft = True
                elif(event.key == K_RIGHT and catrect.x<=WINWIDTH or event.key == K_d and catrect.x<=WINWIDTH):
                    catspeedX=4
                    pressedRight = True
                elif (event.key == K_UP or event.key == K_w):
                    grav = 4
                    if grounded == True:
                        catspeedY = -32
                elif (event.key == K_DOWN or event.key == K_s):
                    pressedDown = True

                    
            elif event.type == KEYUP:
                if (event.key == K_LEFT and catrect.x>=0 or event.key == K_a and catrect.x>=0):
                    pressedLeft = False
                    if pressedRight == False:
                        catspeedX=0
                    else:
                        catspeedX=4
                elif(event.key == K_RIGHT and catrect.x<=WINWIDTH or event.key == K_d and catrect.x<=WINWIDTH):
                    pressedRight = False
                    if pressedLeft == False:
                        catspeedX=0
                    else:
                        catspeedX=-4
                elif (event.key == K_UP or event.key == K_w):
                    grav = 8
                elif (event.key == K_DOWN or event.key == K_s):
                    pressedDown = False


        #Collision detection and Bounce
        catspeedY+=grav #gravity
        catrect.x+=catspeedX
        catrect.y+=catspeedY
        coll = collisionDetect(Xpos=catrect.x,Ypos=catrect.y, Width=catrect.w, Height=catrect.h)
        if coll[0]:
            if coll[1]=="Top":
                catspeedY = 0
                catrect.y = 0
            if coll[1]=="Bottom":
                catspeedY = 0
                catrect.y = (WINHEIGHT-catrect.h)
            if coll[1]=="Left":
                catspeedX = 0
                catrect.x = 0
            if coll[1]=="Right":
                catspeedX = 0
                catrect.x = (WINWIDTH-catrect.w)

        if (catrect.y+catrect.h) >= (WINHEIGHT):
            grounded = True
        else:
            grounded = False
        catrect = DISPLAYSURF.blit(IMAGEDICT['catgirl'],(catrect.x,(catrect.y)))
        pygame.display.update()
        FPSCLOCK.tick(FPS)

__main__()
#try:
#    __main__()
#except:
#    print("Thanks For Playing!")
#    pygame.quit()
#    sys.exit()
    
            
