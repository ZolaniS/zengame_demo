## import statements ##import statements ##import statements ##import statements ##
import pygame, random
from pygame.locals import *
class Enemy():
    ##init ## init ## inti ##
    def __init__(self,FPSCLOCK = None, IMAGEDICT = {}, DISPLAYSURF = None, skin = None, spawn = [0,0], pattern = 0):
        self.skin = skin
        #variable init
        self.pos = spawn
        self.rect = DISPLAYSURF.blit(self.skin, self.pos)
        self.stationary = True
        self.clock = FPSCLOCK#outsourcce this
        self.image = IMAGEDICT#outsource this
        self.display = DISPLAYSURF#outsource this
        self.pattern = pattern#give purpose to this
        self.movement = [0,0]
        self.grab = False
##    def move(self,rectarray, PlayerRect,scroll):
##        self.grab = False
##        if self.pattern == 0:#no purpose yet
##            pass
##        elif self.pattern == 1:#
##            pass
##        elif self.pattern == 2:#
##            pass
##        elif self.pattern == 3:#
##            pass
##        elif self.pattern == 4:#
##            pass
##        elif self.pattern == 5:#
##            pass
##        else:
##            pass
##        
##        adjustedpos = [0,0]
##        adjustedpos[0] = self.pos[0]
##        adjustedpos[1] = self.pos[1]
##        self.skin, adjustedpos
##        return self.rect
    
    def zoom(self,center, newsurf):#attempt to zoom into grapple
        newsurf = pygame.transform.scale2x(newsurf)
        x = self.display.get_width()/2-2*center[0]
        y = self.display.get_height()/2-2*center[1]
        rec = self.display.blit(newsurf,(x,y))
    def drawtimer(self,time):#Ripoff of drawUI for timer
        dil = int(self.image["misc"]["heart"].get_width()/20)
        self.display.blit(self.image["misc"]["UI"], (0, self.display.get_height()-40*dil))
        for x in range(1,time+1):
            if x%2 == 0:
                self.display.blit(self.image["misc"]["heart"],(20*dil*x,self.display.get_height()-30*dil))
            elif x == time:
                self.display.blit(self.image["misc"]["half-heart"],(20*dil*x,self.display.get_height()-30*dil))
        
    def grapple(self,PlayerSkin):#minigame when char collides with enemy
        if PlayerSkin == self.image["drey"]["idle"] or PlayerSkin == self.image["drey"]["walkright"] or PlayerSkin == self.image["drey"]["walkleft"]:
            form = 0#ignore, for later feature
        else:
            form = 0
        #zoom in and play the grapple animation/minigame
        #create loop outside of mainloop
        grapplebar = 0
        timelimit = 60
        timer = -1
        match = 0
        while grapplebar<50 and timer<timelimit:#timer obsolete## FIX ## FIX ## FIX##
            pygame.draw.rect(self.display, (200,200,100), (0,0,25,grapplebar*2))
            
            if timer>= timelimit/2:
                pass#play phase 2 grapple
            else:
                pass#play phase 1 grapple
            if match == 0:
                prompt = random.choice(["CueUp","CueDown","CueLeft","CueRight"])
                self.display.blit(self.image["misc"][prompt],[self.display.get_width()/2,self.display.get_height()/4])
                match = 1
            elif match == 1:
                for event in pygame.event.get():#QTE event handling loop
                    if event.type == KEYDOWN:
                        if (event.key == K_LEFT and prompt == "CueLeft" or event.key == K_a and prompt == "CueLeft"):
                            match = 0#and probably other stuf to up the grapplemeter
                        if (event.key == K_RIGHT and prompt == "CueRight" or event.key == K_d and prompt == "CueRight"):
                            match = 0
                        if (event.key == K_DOWN and prompt == "CueDown" or event.key == K_s and prompt == "CueDown"):
                            match = 0
                        if (event.key == K_UP and prompt == "CueUp" or event.key == K_w and prompt == "CueUp"):
                            match = 0
                    if event.type == QUIT:
                        print("Thanks For Playing!")
                        pygame.quit()
                        sys.exit()
                            
                if match == 0:#QTE prompt changer
                    grapplebar+=10
                    self.display.blit(self.image["misc"][prompt+"!"],[self.display.get_width()/2,self.display.get_height()/4])
                    
            timer+=1
            if timer%5 == 0:
                correctedtimer = int(timer/5)
            self.drawtimer(12-correctedtimer)
            self.clock.tick(15)
            pygame.display.update()
                
        if grapplebar>=50:
            return True#won encounter
        else:
            return False#lost encounter
            


