import pygame, sys, time, random
from BackGroundFunc import BackGround
from EnemyClass import Enemy
from pygame.locals import *


                            


def init():         #Sets up border rects and other basic shitake mushrooms
    
#Global variables
    global IMAGEDICT, WINWIDTH, WINHEIGHT, FPS, DISPLAYSURF, FPSCLOCK, BASICFONT, SPAWN, DILATION, ANNA, UNSEEN
    DILATION = int(2)#scales up size of assets to match 
    WINWIDTH  = int(480*DILATION)
    WINHEIGHT = int(WINWIDTH*3/4)
    assert (WINWIDTH)%120 == 0, "Window dimensions(width and height) invalid: must be multiples of 100"
    FPS = 16 # frames per second settingw
    SPAWN = [0,0]
#color, clock and font
#Displaysurf init
    dire = sys.path[0]
    pygame.init()
    ANNA = pygame.font.Font(dire+"/Font/ANNA____.ttf", 50)
    UNSEEN = pygame.font.Font(dire+"/Font/the_unseen.ttf", 25)
    DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
    pygame.display.set_caption('Zengane the waste of breath')
#color, clock and font
    DISPLAYSURF.fill((200,200,200))#fill screen grey
    FPSCLOCK = pygame.time.Clock()

#Image import
    IMAGEDICT={'drey':{"idle":pygame.image.load(dire+'/Assets/Sprites/drey.gif'),
                "walkright" : pygame.image.load(dire+'/Assets/Sprites/WR.gif'),
                "walkleft"  : pygame.image.load(dire+'/Assets/Sprites/WL.gif')},
               
             "plains": {"bg" : pygame.image.load(dire+"/Assets/misc/Grasslands_WIP.gif") ,
                        "1" : pygame.image.load(dire+"/Assets/Blocks/GrassBlock.gif"),
                        "2" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/DirtBlock.gif"),90) ,
                        "3" : pygame.image.load(dire+"/Assets/Blocks/DirtBlock.gif") ,
                        "4" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/DirtBlock.gif"),270) ,
                        
                        "5" : pygame.image.load(dire+"/Assets/Blocks/GrassSlopeL.gif"),
                        "6" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/GrassSlopeL.gif"),True,False) ,
                        "7" : pygame.image.load(dire+"/Assets/Blocks/DirtSlopeL.gif") ,
                        "8" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/DirtSlopeL.gif"),True,False)},
               
             "caves" : {"bg" : pygame.image.load(dire+"/Assets/misc/Cave_WIP.gif") ,
                        "1" : pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif") ,
                        "2" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif"),90) ,
                        "3" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif"),180) ,
                        "4" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif"),270) ,
                        
                        "5" : pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif") ,
                        "6" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif"),90),
                        "7" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif"),180),
                        "8" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif"),270),},
                        
            "desert": { "bg": pygame.image.load(dire+"/Assets/misc/Desert.gif") ,
                        "1" : pygame.image.load(dire+"/Assets/Blocks/Sand.gif"),
                        "2" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/SandStone.gif"),90),
                        "3" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/SandStone.gif"),180),
                        "4" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/SandStone.gif"),270),
                        
                        "5" : pygame.image.load(dire+"/Assets/Blocks/SandSlope.gif"),
                        "6" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/SandSlope.gif"),True,False),
                        "7" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/SandStoneStair.gif"),False,True),
                        "8" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/SandStoneStair.gif"),True,True)},
         "misc":{"DoorClosed":pygame.image.load(dire+"/Assets/misc/DoorClosed.gif"),
                   "DoorOpen":pygame.image.load(dire+"/Assets/misc/DoorOpen.gif"),
                      "key" : pygame.image.load(dire+"/Assets/misc/key.gif"),
                        "UI": pygame.image.load(dire+"/Assets/misc/WIP_UI2.gif"),
                     "heart": pygame.image.load(dire+"/Assets/misc/heart.gif"),
                "half-heart": pygame.image.load(dire+"/Assets/misc/heart_piece.gif"),
                    "CueUp" : pygame.image.load(dire+"/Assets/misc/cue1.gif"),
                    "CueUp!": pygame.image.load(dire+"/Assets/misc/cue2.gif"),
                  "CueDown" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue1.gif"),180),
                  "CueDown!": pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue2.gif"),180),
                  "CueLeft" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue1.gif"),90),
                  "CueLeft!": pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue2.gif"),90),
                 "CueRight" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue1.gif"),270),
                 "CueRight!": pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue2.gif"),270)},
               
            "trap":{"SpikeUp" : pygame.image.load(dire+"/Assets/trap/spike.gif"),
                    "SpikeDown":pygame.transform.rotate(pygame.image.load(dire+"/Assets/trap/spike.gif"),180),
                    "SpikeLeft":pygame.transform.rotate(pygame.image.load(dire+"/Assets/trap/spike.gif"),270),
                    "SpikeRight":pygame.transform.rotate(pygame.image.load(dire+"/Assets/trap/spike.gif"),90)},
                "eye":{"eyeR":pygame.image.load(dire+"/Assets/Sprites/eye.gif"),
                       "eyeL":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/eye.gif"),True,False)},
               "frog":{"frog1L":pygame.image.load(dire+"/Assets/Sprites/idlefrog.gif"),
                       "frog1R":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/idlefrog.gif"),True,False),
                       "frog2L":pygame.image.load(dire+"/Assets/Sprites/idlefrog2.gif"),
                       "frog2R":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/idlefrog2.gif"),True,False),
                       "frogchargeL":pygame.image.load(dire+"/Assets/Sprites/frogcharge.gif"),
                       "frogchargeR":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/frogcharge.gif"),True,False),
                       "frogattackL":pygame.image.load(dire+"/Assets/Sprites/frogattack.gif"),
                       "frogattackR":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/frogattack.gif"),True,False)}

               }
    #Apply dilation to all images
    for imageType in IMAGEDICT:
        for image in IMAGEDICT[imageType]:
##            if IMAGEDICT[imageType][image].__doc__[0] == "S":
            IMAGEDICT[imageType][image] = pygame.transform.scale(IMAGEDICT[imageType][image],(IMAGEDICT[imageType][image].get_width()*DILATION,IMAGEDICT[imageType][image].get_height()*DILATION))
##            elif IMAGEDICT[imageType][image].__doc__[0] == "d":
##                try:
##                    for skin in image:
##                        IMAGEDICT[imageType][image][skin] = pygame.transform.scale(IMAGEDICT[imageType][image][skin],(IMAGEDICT[imageType][image][skin].get_width()*DILATION,IMAGEDICT[imageType][image][skin].get_height()*DILATION))
##                except:
##                    break
##def BackGround(lvl):

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def Title():
    bgcolor = (100,100,100)
    textColor = (255,255,255)
    DISPLAYSURF.fill(bgcolor)
    p = ANNA.render('NAMETHIS', True, textColor, bgcolor)
    DISPLAYSURF.blit(p,(10,0))
    p = UNSEEN.render('START', True, textColor, bgcolor)
    start = DISPLAYSURF.blit(p,(10,50))
    p = UNSEEN.render('POINTLESS BUTTON', True, textColor, bgcolor)
    DISPLAYSURF.blit(p,(10,100))
    pygame.display.update()
    proceed = False
    fadebg = False
    fadetext = False
    redraw = False
    click = [0,0]
    r=1
    while proceed == False:
        for event in pygame.event.get():
                if event.type == QUIT:
                        print("Thanks For Playing!")
                        pygame.quit()
                        sys.exit()
                elif event.type == MOUSEBUTTONDOWN:
                    click = pygame.mouse.get_pos()
                    if start.collidepoint(click):
                        fadetext = True
                        redraw = True
        if r == 15:
            proceed = True
        else:
            if fadebg:
                r,g,b = bgcolor
                bgcolor = (r-10,g-10,b-10)
                
            if fadetext:
                r,g,b = textColor
                textColor = (r-15,g-15,b-15)
                if r == 150:
                    fadebg = True
            if redraw:
                DISPLAYSURF.fill(bgcolor)
                p = ANNA.render('NAMETHIS', True, textColor, bgcolor)
                DISPLAYSURF.blit(p,(10,0))
                p = UNSEEN.render('START', True, textColor, bgcolor)
                start = DISPLAYSURF.blit(p,(10,50))
                p = UNSEEN.render('POINTLESS BUTTON', True, textColor, bgcolor)
                DISPLAYSURF.blit(p,(10,100))
                pygame.display.update()
        FPSCLOCK.tick(10)
def gameover(cause):
    bgcolor = (100,100,100)
    textColor = (255,255,255)
    DISPLAYSURF.fill(bgcolor)
    p = ANNA.render('GAME OVER', True, textColor, bgcolor)
    DISPLAYSURF.blit(p,(10,0))
    p = UNSEEN.render('You were killed by '+cause, True, textColor, bgcolor)
    DISPLAYSURF.blit(p,(10,50))
    p = UNSEEN.render('Press R to restart', True, textColor, bgcolor)
    DISPLAYSURF.blit(p,(10,100))
    pygame.display.update()

    
    tryagain = False
    while not tryagain:
        for event in pygame.event.get():
                if event.type == QUIT:
                        print("Thanks For Playing!")
                        pygame.quit()
                        sys.exit()
                elif event.type == KEYDOWN:
                    if (event.key == K_r):
                        tryagain = True

    
    for x in range(0,10):# UNTESTED FIX # UNTESTED FIX # UNTESTED FIX # UNTESTED FIX # UNTESTED FIX #
        r,g,b = bgcolor
        r,g,b = textColor
        textColor = (r-15,g-15,b-15)
        bgcolor = (r-10,g-10,b-10)
        DISPLAYSURF.fill(bgcolor)
        p = ANNA.render('GAME OVER', True, textColor, bgcolor)
        DISPLAYSURF.blit(p,(10,0))
        p = UNSEEN.render('You were killed by '+cause, True, textColor, bgcolor)
        DISPLAYSURF.blit(p,(10,50))
        p = UNSEEN.render('Press R to restart', True, textColor, bgcolor)
        DISPLAYSURF.blit(p,(10,100))
        pygame.display.update()
def drawUI(health):
    DISPLAYSURF.blit(IMAGEDICT["misc"]["UI"], (0, WINHEIGHT-40*DILATION))
    for x in range(1,health+1):
        if x%2 == 0:
            DISPLAYSURF.blit(IMAGEDICT["misc"]["heart"],(20*DILATION*x,WINHEIGHT-30*DILATION))
        elif x == health:
            DISPLAYSURF.blit(IMAGEDICT["misc"]["half-heart"],(20*DILATION*x,WINHEIGHT-30*DILATION))
def collisionDetect(PlayerRect, scroll, collarray=[], speed=[], IMAGEDICT = {}):
    returnType = "default"
        
    PlayerRect.x+=speed[0]#Apply horizontal movement, and check for collisions
    index = PlayerRect.collidelist(collarray)
    if index != -1:
        pygame.draw.rect(DISPLAYSURF, (200,200,200), (75,50,25,150))
        if PlayerRect.colliderect(collarray[index]) or True:#final priority normal blocks
            if speed[0]>=0:#//PlayerRect.right > collarray[index].left://
                PlayerRect.right = collarray[index].left
            elif speed[0]<0:#//PlayerRect.left < collarray[index].right://
                PlayerRect.left = collarray[index].right


    PlayerRect.y+=speed[1]#Apply Vertical movement and check for collisions
    index = PlayerRect.collidelist(collarray)
    if index != -1:
        pygame.draw.rect(DISPLAYSURF, (200,200,200), (0,50,25,150))
        if PlayerRect.colliderect(collarray[index]):#final priority normal blocks
            if speed[1]>=0:#//PlayerRect.bottom > collarray[index].top://
                returnType = "grounded"
                PlayerRect.bottom = collarray[index].top
                speed[1] = 4
            elif speed[1]<0:#//PlayerRect.top < collarray[index].bottom://
                PlayerRect.top = collarray[index].bottom

                

    return PlayerRect,speed,returnType,index
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def redraw(PlayerRect, scroll, RectArray,speed,slack = 100):
    
    Rect = []
    if PlayerRect.centerx <slack:#######SCROLL LEFT#####
        scroll[0] += -1*speed[0]
        PlayerRect.centerx = slack
    elif PlayerRect.centerx > WINWIDTH-slack:# and scroll[0]<WINWIDTH-slack:#######SCROLL RIGHT#######
        scroll[0] += -1*speed[0]
        PlayerRect.centerx = WINWIDTH-slack
    collision_array = []
    for surf in RectArray:#redraw all map and apply dilation and scroll
        collision_array.append(DISPLAYSURF.blit(surf[1],( (surf[0].x+scroll[0]) ,(surf[0].y) )))
    return scroll, PlayerRect, collision_array


def parseInput(PlayerRect,PlayerSpeed,grounded, pressed):
    exitType = 0
    for event in pygame.event.get(): # event handling loop
        if event.type == QUIT:#graceful quit
            print("Thanks For Playing!")
            pygame.quit()
            sys.exit()
            
        elif event.type == KEYDOWN:
            if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                pressed["left"] = True
            elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                pressed["right"] = True
            elif (event.key == K_UP or event.key == K_w):
                pressed["up"] = True#note: add coyote time and parabolic jumping
            elif (event.key == K_DOWN or event.key == K_s):
                pressed["down"] = True
            elif (event.key == K_r):
                exitType = 1

                
        elif event.type == KEYUP:
            if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                pressed["left"] = False
                #if pressed["right"]:
                    #PlayerSpeed[0]=0#graceful direction switching
                #else:
                    #PlayerSpeed[0]=4
            elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                pressed["right"] = False
                #if pressed["left"] == False:
                    #PlayerSpeed[0]=0#graceful direction switching
                #else:
                    #PlayerSpeed[0]=-4
            elif (event.key == K_UP or event.key == K_w):
                pressed["up"] = False
            elif (event.key == K_DOWN or event.key == K_s):
                pressed["down"] = False#stand-in for interaction/crouch
                
        elif event.type == MOUSEBUTTONDOWN:#tp to click hack## remove later ## remove later ## remove later ##
            exitType = 2
            click = pygame.mouse.get_pos() 
    if exitType == 0:#default exit type
        return exitType, pressed, PlayerSpeed
    if exitType == 1:#restart exit type
        return exitType, "useless second return"
    if exitType == 2:#hack exit type
        return exitType, click
def walk(skin, pressed, speed, grounded_timer):#checks current step of walk cycle and returns logical next step.
    #left acceleration/deceleration ## INCORPORATE pressed["dominant"] ## INCORPORATE pressed["dominant"] ##
    if pressed["left"] and speed[0] > -8*DILATION:
        speed[0]-= 4*DILATION
    elif pressed["left"] and speed[0] > 0:
        speed[0]-= 8*DILATION
    elif not pressed["left"] and speed[0] < 0:
        speed[0]+= 8*DILATION
    #right acceleration/deceleration
    if pressed["right"] and speed[0] < 8*DILATION:
        speed[0]+= 4*DILATION
    elif pressed["right"] and speed[0] < 0:
        speed[0]+= 8*DILATION
    elif not pressed["right"] and speed[0] > 0:
        speed[0]-= 8*DILATION

    #jump handling
    if speed[1] < 32*DILATION:####
        speed[1]+=4*DILATION####
    jump = False
    if pressed["up"]:
        jump = True
    grounded_timer[1].pop()
    grounded_timer[1].insert(0,jump)
    
    if True in grounded_timer[0] and pressed["up"]:
        speed[1] = -16*DILATION
    if True in grounded_timer[1] and not pressed["up"] and speed[0] < 0:
        speed[1] = int(speed[1]/2)
    
    
        
    rskin = skin
    if pressed["left"] == True or pressed["right"] == True:
        if skin == IMAGEDICT['drey']['walkleft'] or skin == IMAGEDICT['drey']['idle']:
            rskin = IMAGEDICT['drey']['walkright']
        elif skin == IMAGEDICT['drey']['walkright']:
            rskin = IMAGEDICT['drey']['walkleft']
    if not True in pressed.items():
        rskin = IMAGEDICT['drey']['idle']
    return rskin, speed, grounded_timer
def __main__():
    
    init()#var setup
    #Title()
    level = 1
    enemyarray = []
    L = BackGround(level, IMAGEDICT, DISPLAYSURF)#create background return list of rect/image lists
    RectArray = L[0]
    skin = IMAGEDICT['drey']['idle']
    PlayerRect = DISPLAYSURF.blit(skin,DILATION*L[1])#create player rect
    pressed = {"left": False, "right": False, "up": False, "down": False, "dominant": "down"}
    grounded = False
    grav = 4
    health = 10
    invincible = [False,False,False,False,False,False,False,False,False,False,False,False,False,False,False]
    PlayerSpeed = [0,0]
    SCROLL = [0,0]
    inventory = []
    bg = L[3]
    objarray = L[4]
    for obj in objarray:
        obj["rect"] = DISPLAYSURF.blit(IMAGEDICT[obj["skin"][0]][obj["skin"][1]],obj["pos"])
            
    grounded_timer = [[False,False,False,False,False],[False,False,False,False,False]]
    for enemy in L[2]:#creates enemies from positions in L[2]
        enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT[enemy[2]][enemy[3]],[enemy[0],enemy[1]])
        enemyarray.append(enemy)
    while True: # main game loop
        DISPLAYSURF.blit(IMAGEDICT[bg]["bg"],(0,0))
        SCROLL, PlayerRect, collision_array = redraw(PlayerRect,SCROLL,RectArray,PlayerSpeed)#[0]#redraws background efficiently

        

        exitType = parseInput(PlayerRect, PlayerSpeed, grounded, pressed)
        if exitType[0] == 0:#normal exit type
            pressed = exitType[1]
            skin, PlayerSpeed, grounded_timer = walk(skin, pressed, PlayerSpeed, grounded_timer)
        elif exitType[0] == 1:#restart exit type ####BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##
            L = BackGround(level, IMAGEDICT, DISPLAYSURF)
            RectArray = L[0]
            enemyarray = L[2]
            PlayerRect.x = L[1][0]
            PlayerRect.y = L[1][1]
            PlayerSpeed = [0,0]
            enemyarray = []
            SCROLL = [0,0]
            for enemy in L[2]:
                enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT[enemy[2]][enemy[3]],[enemy[0],enemy[1]])
                enemyarray.append(enemy)
        elif exitType[0] == 2:#click hack exit type
            PlayerRect.x = exitType[1][0]
            PlayerRect.y = exitType[1][1]
        else:
            print("bunked up")#oof
        
        
        col = collisionDetect(PlayerRect,SCROLL,collision_array,PlayerSpeed,IMAGEDICT)
        PlayerRect = col[0]
        PlayerSpeed = col[1]

            
        if col[2] == "grounded":#grounded exit, third priority
            grounded = True
                
        else:#no special case exit
            grounded = False
        grounded_timer[0].pop()
        grounded_timer[0].insert(0,grounded)
        
        invincible.pop()
        invincible.insert(0,False)
        #print(SCROLL)#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHHH!!!
        counter = 0
        for obj in objarray:
            obj["rect"] = DISPLAYSURF.blit(IMAGEDICT[obj["skin"][0]][obj["skin"][1]],[obj["pos"][0]+SCROLL[0],obj["pos"][1]])
            if obj["rect"].colliderect(PlayerRect):
                if IMAGEDICT[obj["skin"][0]][obj["skin"][1]] == IMAGEDICT["misc"]["key"]:
                    inventory.append("k")
                    objarray.pop(counter)
                if IMAGEDICT[obj["skin"][0]][obj["skin"][1]] == IMAGEDICT["misc"]["DoorClosed"] and "k" in inventory:
                    inventory.remove("k")
                    level+=1
                    L = BackGround(level, IMAGEDICT, DISPLAYSURF)
                    RectArray = L[0]
                    PlayerRect.x = L[1][0]
                    PlayerRect.y = L[1][1]
                    enemyarray = []
                    bg = L[3]
                    SCROLL = [0,0]
                    objarray = L[4]
                    for obj in objarray:
                        obj["rect"] = DISPLAYSURF.blit(IMAGEDICT[obj["skin"][0]][obj["skin"][1]],obj["pos"])
                    for enemy in L[2]:#creates enemies from positions in L[2]
                        enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT[enemy[2]][enemy[3]],[enemy[0],enemy[1]])
                        enemyarray.append(enemy)
                if IMAGEDICT[obj["skin"][0]][obj["skin"][1]] in IMAGEDICT["trap"].values() and not True in invincible:
                    health -=1
                    invincible.pop()
                    invincible.insert(0,True)
            counter+=1
        

        counter = 0
        for enemy in enemyarray:#moves and checks for grapple in each enemy
            enemy.rect = DISPLAYSURF.blit(enemy.skin, [enemy.pos[0]+SCROLL[0],enemy.pos[1]])#moves and checks for grapple on each enemy
            if enemy.rect.colliderect(PlayerRect):#if enemy hits player
                if not True in invincible:
                    enemy.zoom([PlayerRect.x,PlayerRect.y],pygame.display.get_surface())#zoom
                    if(enemy.grapple(pygame.transform.scale2x(skin))):#if player wins grapple
                        enemyarray.pop(counter)#kill enemy
                    else:
                        health -=1
                    pressed = {"left": False, "right": False, "up": False, "down": False}#, "dominant": "down"}
                    PlayerSpeed = [0,0]
            counter+=1

        drawUI(health)
        PlayerRect = DISPLAYSURF.blit(skin,(PlayerRect.x,PlayerRect.y))#draw character
        pygame.display.update()#update screen
        FPSCLOCK.tick(FPS)


##class Enemy():



__main__()
#try:
#    __main__()
#except:
#    print("Thanks For Playing!")
#    pygame.quit()
#    sys.exit()
    
            
