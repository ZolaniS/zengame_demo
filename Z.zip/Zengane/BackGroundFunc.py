import pygame
def BackGround(lvl, IMAGEDICT, DISPLAYSURF):
# LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # 
    y=0
    with open("levels.txt") as t:
        dest = False
        rectarray = []
        enemyarray = []
        objarray = []
        print(IMAGEDICT["plains"]["1"].get_width())
        stdSize = IMAGEDICT["plains"]["1"].get_width()
        for line in t:
            x=0
            if "$" in line and dest == True:
                break
            if dest == True and "#" not in line:
                for chara in line:
                    offsety = 0
                    #SPECIAL CASES #SPECIAL CASES #SPECIAL CASES #SPECIAL CASES #
                    if chara == "\n":
                        break
                    if chara == "   " or chara == "n":
                        x+=1
                        continue
                    if chara == "*":
                        SPAWN = [x*stdSize,y*stdSize]
                    #ENEMIES # ENEMIES # ENEMIES # ENEMIES # ENEMIES # 
                    if chara == "I":
                        eye = [x*stdSize,y*stdSize,"eye","eyeR"]
                        enemyarray.append(eye)
                    if chara == "F":
                        eye = [x*stdSize,y*stdSize,"frog","frog1R"]
                        enemyarray.append(eye)
                    # TRAPS # OBJECTS # TRAPS # OBJECTS # TRAPS # OBJECTS # 
                    if chara == "^":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeUp"]}
                        objarray.append(spike)
                    if chara.lower() == "v":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeDown"]}
                        objarray.append(spike)
                    if chara == "<":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeLeft"]}
                        objarray.append(spike)
                    if chara == ">":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeDown"]}
                        objarray.append(spike)
                    if chara == "K":
                        key = {"pos":[x*stdSize,y*stdSize],"skin":["misc","key"]}
                        objarray.append(key)
                    if chara == "D":
                        door = {"pos":[x*stdSize,y*stdSize],"skin":["misc","DoorClosed"]}
                        objarray.append(door)
                    # BLOCKS # BLOCKS # BLOCKS # BLOCKS # BLOCKS # BLOCKS #
                    if chara not in IMAGEDICT[level[0]]:
                        pygame.draw.rect(DISPLAYSURF, (0,200,200),((x*stdSize),(y*stdSize),8,8))
                    else:
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT[level[0]][chara], (x*stdSize,y*stdSize)),IMAGEDICT[level[0]][chara]])
#LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # 
                    x+=1
                y+=1
            if "$" in line:
                level = line.rpartition("$")
                if lvl == level[2].strip("\n") or lvl == int(level[2].strip("\n")):
                    dest = True
        return rectarray, SPAWN, enemyarray, level[0], objarray
