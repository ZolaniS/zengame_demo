import pygame, random
from pygame.locals import *
class obj():
    def __init__(self,position,skin, damage, DISPLAY):
        self.pos = position
        self.skin = skin
        self.objrect = DISPLAY.blit(skin, position)
        self.damage = damage        
