import pygame, sys, random
from BackGroundFunc import BackGround
from EnemyClass import Enemy
from pygame.locals import *


                            


def init():         #Sets up border rects and other basic shitake mushrooms
    
#Global variables
    global IMAGEDICT, WINWIDTH, WINHEIGHT, FPS, DISPLAYSURF, FPSCLOCK, BASICFONT, SPAWN, DILATION, ANNA, UNSEEN
    
    with open("SETTINGS") as t:                                     #opens settings file to set DILATION and FPS
        op = t.readline()
        setting = op.rpartition(":")[2]
        FPS = int(setting.strip("\n"))
        op = t.readline()
        setting = op.rpartition(":")[2]
        DILATION = int(setting.strip("\n"))
        
    WINWIDTH  = int(480*DILATION)                                   #makes appropriately 3:4 ratio window width and height variables
    WINHEIGHT = int(WINWIDTH*3/4)
    assert (WINWIDTH)%120 == 0, "Window dimensions(width and height) invalid: must be multiples of 100"
    SPAWN = [0,0]
    
#color, clock and font
#Displaysurf init
    dire = sys.path[0]                                              #temporary var that AUTOMATICALLY FINDS THE FILE PATH TO THE GAME FOLDER!?!?!?!
    pygame.init()                                                   #obligatory pygame.init
    ANNA = pygame.font.Font(dire+"/Font/ANNA____.ttf", 50)          #created propper title...
    UNSEEN = pygame.font.Font(dire+"/Font/the_unseen.ttf", 25)      #...handwriting font creation
    DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
    pygame.display.set_caption('Zengane the waste of breath')       #create window
#color, clock and font
    FPSCLOCK = pygame.time.Clock()

#Image import
    IMAGEDICT={'drey':{"idle":pygame.image.load(dire+'/Assets/Sprites/DreyWalk1.gif'),      #Drey dict: holds the various animations frames of player
                        "walkr1" : pygame.image.load(dire+'/Assets/Sprites/DreyWalk1.gif'), #cycle of frames walking left
                        "walkr2" : pygame.image.load(dire+'/Assets/Sprites/DreyWalk2.gif'),
                        "walkr3" : pygame.image.load(dire+'/Assets/Sprites/DreyWalk3.gif'),
                        "walkr4" : pygame.image.load(dire+'/Assets/Sprites/DreyWalk4.gif'),
                        "walkr5" : pygame.image.load(dire+'/Assets/Sprites/DreyWalk3.gif'),
                        "walkr6" : pygame.image.load(dire+'/Assets/Sprites/DreyWalk2.gif'),#cycle of frames walking right VVV down there VVV
                        "walkl1" : pygame.transform.flip(pygame.image.load(dire+'/Assets/Sprites/DreyWalk1.gif'),True,False),
                        "walkl2" : pygame.transform.flip(pygame.image.load(dire+'/Assets/Sprites/DreyWalk2.gif'),True,False),
                        "walkl3" : pygame.transform.flip(pygame.image.load(dire+'/Assets/Sprites/DreyWalk3.gif'),True,False),
                        "walkl4" : pygame.transform.flip(pygame.image.load(dire+'/Assets/Sprites/DreyWalk4.gif'),True,False),
                        "walkl5" : pygame.transform.flip(pygame.image.load(dire+'/Assets/Sprites/DreyWalk3.gif'),True,False),
                        "walkl6" : pygame.transform.flip(pygame.image.load(dire+'/Assets/Sprites/DreyWalk2.gif'),True,False)},

               #okay so this is really cool and needs explaining. In each level (created in levels.txt, which you should check out)
               #the same characters for similar types of blocks are used in each level, but each block has a different skin according
               #to the "biome". the biome is decided according to the level tag at the top of each level layout. this string is used
               #as the key for IMAGEDICT, which gives acces to the biome specific dictionary inside. this, coupled with the identical
               #contents of all the dictionaries, means that the same level layout can be completely reskinned by changing the level tag
               #
               #take a moment to revel in the awesomeness of this handy mechanic I toiled to figure out. ^o^
               
             "plains": {"bg" : pygame.image.load(dire+"/Assets/misc/Grasslands_WIP.gif") ,
                        "1" : pygame.image.load(dire+"/Assets/Blocks/GrassBlock.gif"),#grass facing up
                        "2" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/DirtBlock.gif"),90) ,#dirt facing left
                        "3" : pygame.image.load(dire+"/Assets/Blocks/DirtBlock.gif") ,#dirt facing down
                        "4" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/DirtBlock.gif"),270) ,#dirt facing right
                        
                        "5" : pygame.image.load(dire+"/Assets/Blocks/GrassSlopeL.gif"),
                        "6" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/GrassSlopeL.gif"),True,False) ,
                        "7" : pygame.image.load(dire+"/Assets/Blocks/DirtSlopeL.gif") ,
                        "8" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/DirtSlopeL.gif"),True,False)},
               
             "caves" : {"bg" : pygame.image.load(dire+"/Assets/misc/Cave_WIP.gif") ,
                        "1" : pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif") ,
                        "2" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif"),90) ,
                        "3" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif"),180) ,
                        "4" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneBlock.gif"),270) ,
                        
                        "5" : pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif") ,
                        "6" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif"),90),
                        "7" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif"),180),
                        "8" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/StoneSlopeL.gif"),270),},
                        
            "desert": { "bg": pygame.image.load(dire+"/Assets/misc/Desert.gif") ,
                        "1" : pygame.image.load(dire+"/Assets/Blocks/Sand.gif"),
                        "2" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/SandStone.gif"),90),
                        "3" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/SandStone.gif"),180),
                        "4" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/Blocks/SandStone.gif"),270),
                        
                        "5" : pygame.image.load(dire+"/Assets/Blocks/SandSlope.gif"),
                        "6" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/SandSlope.gif"),True,False),
                        "7" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/SandStoneStair.gif"),False,True),
                        "8" : pygame.transform.flip(pygame.image.load(dire+"/Assets/Blocks/SandStoneStair.gif"),True,True)},
               
         "misc":{"DoorClosed":pygame.image.load(dire+"/Assets/misc/DoorClosed.gif"),#miscellaneous sprites
                   "DoorOpen":pygame.image.load(dire+"/Assets/misc/DoorOpen.gif"),
                      "key" : pygame.image.load(dire+"/Assets/misc/key.gif"),
                        "UI": pygame.image.load(dire+"/Assets/misc/WIP_UI2.gif"),
                     "heart": pygame.image.load(dire+"/Assets/misc/heart.gif"),
                "half-heart": pygame.image.load(dire+"/Assets/misc/heart_piece.gif"),
                    "CueUp" : pygame.image.load(dire+"/Assets/misc/cue1.gif"),#MAKE THESE LARGER XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                    "CueUp!": pygame.image.load(dire+"/Assets/misc/cue2.gif"),
                  "CueDown" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue1.gif"),180),
                  "CueDown!": pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue2.gif"),180),
                  "CueLeft" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue1.gif"),90),
                  "CueLeft!": pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue2.gif"),90),
                 "CueRight" : pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue1.gif"),270),
                 "CueRight!": pygame.transform.rotate(pygame.image.load(dire+"/Assets/misc/cue2.gif"),270),
                 "sign"     : pygame.image.load(dire+"/Assets/misc/sign.gif")},
               
            "trap":{"SpikeUp" : pygame.image.load(dire+"/Assets/trap/spike.gif"),   #traps: only spikes, but will be expanded
                    "SpikeDown":pygame.transform.rotate(pygame.image.load(dire+"/Assets/trap/spike.gif"),180),
                    "SpikeLeft":pygame.transform.rotate(pygame.image.load(dire+"/Assets/trap/spike.gif"),270),
                    "SpikeRight":pygame.transform.rotate(pygame.image.load(dire+"/Assets/trap/spike.gif"),90)},

               #basic enemy sprites. be nice to them because these atrocities unto the heavens are very sensitive and will cry
               #I will make them more interesting, add, and implement these cool monsters. will likely enlist another artist.
               
                "eye":{"eyeR":pygame.image.load(dire+"/Assets/Sprites/eye.gif"),
                       "eyeL":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/eye.gif"),True,False)},
               "frog":{"frog1L":pygame.image.load(dire+"/Assets/Sprites/idlefrog.gif"),
                       "frog1R":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/idlefrog.gif"),True,False),
                       "frog2L":pygame.image.load(dire+"/Assets/Sprites/idlefrog2.gif"),
                       "frog2R":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/idlefrog2.gif"),True,False),
                       "frogchargeL":pygame.image.load(dire+"/Assets/Sprites/frogcharge.gif"),
                       "frogchargeR":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/frogcharge.gif"),True,False),
                       "frogattackL":pygame.image.load(dire+"/Assets/Sprites/frogattack.gif"),
                       "frogattackR":pygame.transform.flip(pygame.image.load(dire+"/Assets/Sprites/frogattack.gif"),True,False)}

               }
##    SOUNDDICT = {"enemy":{"frogcharge": pygame.mixer.sound(dire+"frogcharge.wav"},
##                "drey":{        etc...
    #Yet again, this is really cool and should be explained. when I began this project, I was working on a screen with VERY low resolution, so
    #by default everything was very small. I cleverly decided to add in a scalability feature, using the global variable DILATION to scale everything
    #over here, I go through each dict within a dict, and scale it up by a factor of DILATION. Now, I can hear you saying ,"but what if I want to make
    #my images an arbitrary dict/list depth and this inflexible method of scaling the program would crash when trying to sate my arbitrary desires?
    #I hunger for an image within a dict within a dict withing ANOTHER dict!"Well, I actually developed a more flexible solution to this problem,
    #and promptly deleted it to debug a later deemed unrelated issue, but never reimplemented it in a bout of hardheaded stupidity. I could redo it,
    #because I know the gist of what I did, but foolishly refuse to do so to maintain this arbitrary standard image list depth. *insert flipped bird here*
    for imageType in IMAGEDICT:
        for image in IMAGEDICT[imageType]:
            IMAGEDICT[imageType][image] = pygame.transform.scale(IMAGEDICT[imageType][image],(IMAGEDICT[imageType][image].get_width()*DILATION,IMAGEDICT[imageType][image].get_height()*DILATION))
##def BackGround(lvl):

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#the next three functions are menu screens and therefore (un)interesting, but inflexible code
def Title():
    #set up text color, and set background color
    bgcolor = (100,100,100)         #somewhat dark grey
    textColor = (255,255,255)       #white
    DISPLAYSURF.fill(bgcolor) 

    #draws obvious text snippets using arbitrary temporary variable p. start saved to later provide click checking
    p = ANNA.render('NAMETHIS', True, textColor)
    DISPLAYSURF.blit(p,(10,0))
    p = UNSEEN.render('START', True, textColor)
    start = DISPLAYSURF.blit(p,(10,50))
    p = UNSEEN.render('POINTLESS BUTTON', True, textColor)
    DISPLAYSURF.blit(p,(10,100))
    pygame.display.update()

    #ignore these variables, don't worry about it.
    proceed = False
    fadebg = False
    fadetext = False
    redraw = False
    click = [0,0]
    r=1
    #loop repeats until player starts game
    while proceed == False:
        #event loop: checks if player closes game, or hits start
        for event in pygame.event.get():
                if event.type == QUIT:
                        print("Thanks For Playing!")
                        pygame.quit()
                        sys.exit()
                elif event.type == MOUSEBUTTONDOWN:
                    click = pygame.mouse.get_pos()
                    if start.collidepoint(click):   #if they hit start, begin fade
                        fadetext = True
                        redraw = True

        #when colors are about to be black, exit the loop and start the game
        if r == 15:
            proceed = True
        else:
            #decrease RGB values of the background color
            if fadebg:
                r,g,b = bgcolor
                bgcolor = (r-10,g-10,b-10)
            #the same thing at a faster speed with a trigger for fading background so that they conicide on black (0,0,0)
            if fadetext:
                r,g,b = textColor
                textColor = (r-15,g-15,b-15)
                if r == 150:
                    fadebg = True
            #redraw the previous info to reflect the darkening
            if redraw:
                DISPLAYSURF.fill(bgcolor)
                p = ANNA.render('NAMETHIS', True, textColor)
                DISPLAYSURF.blit(p,(10,0))
                p = UNSEEN.render('START', True, textColor)
                start = DISPLAYSURF.blit(p,(10,50))
                p = UNSEEN.render('POINTLESS BUTTON', True, textColor)
                DISPLAYSURF.blit(p,(10,100))
                pygame.display.update()
        #omnipresent sleep statement, so the computer doesn't explode.
        FPSCLOCK.tick(10)
def gameover(cause):#same idea as above, but I messed up, only to find that the fade makes a pleasant flash  of white before ending
    bgcolor = (100,100,100)
    textColor = (255,255,255)
    DISPLAYSURF.fill(bgcolor)
    p = ANNA.render('GAME OVER', True, textColor)
    DISPLAYSURF.blit(p,(10,0))
    p = UNSEEN.render('You were killed by '+cause, True, textColor)# cool flexible cause of death flavor
    DISPLAYSURF.blit(p,(10,50))
    p = UNSEEN.render('Press R to restart', True, textColor)
    DISPLAYSURF.blit(p,(10,100))
    pygame.display.update()
    
    tryagain = False
    while not tryagain:
        for event in pygame.event.get():
                if event.type == QUIT:
                        print("Thanks For Playing!")
                        pygame.quit()
                        sys.exit()
                elif event.type == KEYDOWN:
                    if (event.key == K_r):
                        tryagain = True
                        
    for x in range(0,10):
        r,g,b = bgcolor
        r,g,b = textColor
        textColor = (r-15,g-15,b-15)
        bgcolor = (r-10,g-10,b-10)
        DISPLAYSURF.fill(bgcolor)
        p = ANNA.render('GAME OVER', True, textColor)
        DISPLAYSURF.blit(p,(10,0))
        p = UNSEEN.render('You were killed by '+cause, True, textColor)
        DISPLAYSURF.blit(p,(10,50))
        p = UNSEEN.render('Press R to restart', True, textColor)
        DISPLAYSURF.blit(p,(10,100))
        pygame.display.update()
        
def Pause():#same idea as above, but with a nod to an unimplemented settings menu and no fade
    bgcolor = (200,200,250)
    textColor = (50,0,0)
    DISPLAYSURF.fill(bgcolor)
    p = ANNA.render('Paused', True, textColor)
    DISPLAYSURF.blit(p,(10,0))
    p = UNSEEN.render('Resume', True, textColor)
    start = DISPLAYSURF.blit(p,(10,50))
    p = UNSEEN.render('Settings(unimplemented)', True, textColor)
    DISPLAYSURF.blit(p,(10,100))
    pygame.display.update()
    proceed = False
    fadebg = False
    fadetext = False
    redraw = False
    click = [0,0]
    r=1
    while proceed == False:
        for event in pygame.event.get():
                if event.type == QUIT:
                        print("Thanks For Playing!")
                        pygame.quit()
                        sys.exit()
                elif event.type == MOUSEBUTTONDOWN:
                    click = pygame.mouse.get_pos()
                    if start.collidepoint(click):
                        proceed = True
        #omnipresent sleep statement, so the computer doesn't explode.
        FPSCLOCK.tick(10)
        
def drawUI(health, text = None):#WIERD FLASHING PLAYER WHEN READING SIGNS XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    #always draws UI box
    DISPLAYSURF.blit(IMAGEDICT["misc"]["UI"], (0, WINHEIGHT-40*DILATION))
    
    if text == None:    #if no text to read, display health
        for x in range(1,health+1):
            if x%2 == 0:
                DISPLAYSURF.blit(IMAGEDICT["misc"]["heart"],(20*DILATION*x,WINHEIGHT-30*DILATION))
            elif x == health:
                DISPLAYSURF.blit(IMAGEDICT["misc"]["half-heart"],(20*DILATION*x,WINHEIGHT-30*DILATION))
    else:               #if text to read, display text
        p = UNSEEN.render(text, True, (0,0,0))
        DISPLAYSURF.blit(p,(20*DILATION,WINHEIGHT-30*DILATION))
        pygame.display.update()
            
def collisionDetect(PlayerRect, scroll, collarray=[], speed=[], IMAGEDICT = {}):
    returnType = "default"
    safe = [False,False]
        
    PlayerRect.x+=speed[0]  #Apply horizontal movement, and check for collisions
    index = PlayerRect.collidelist(collarray)
    side = None
    if index != -1:
        pygame.draw.rect(DISPLAYSURF, (200,200,200), (75,50,25,150))
        if PlayerRect.colliderect(collarray[index]) or True:#final priority normal blocks
            if speed[0]>=0: #//PlayerRect.right > collarray[index].left://
                PlayerRect.right = collarray[index].left
                side = "left"
            elif speed[0]<0:#//PlayerRect.left < collarray[index].right://
                PlayerRect.left = collarray[index].right
                side = "right"
                
    index = PlayerRect.collidelist(collarray)   #checks if player still colliding, even after moving 
    if index == -1:
        safe[0] = True
    else:
        pass#print("need to get to safety1")
        
    PlayerRect.y+=speed[1]  #Apply Vertical movement and check for collisions
    index = PlayerRect.collidelist(collarray)
    if index != -1:
        pygame.draw.rect(DISPLAYSURF, (200,200,200), (0,50,25,150))
        if PlayerRect.colliderect(collarray[index]):#final priority normal blocks
            if speed[1]>=0: #//PlayerRect.bottom > collarray[index].top://
                returnType = "grounded"
                PlayerRect.bottom = collarray[index].top
                side = "bottom"
                speed[1] = 4
            elif speed[1]<0:#//PlayerRect.top < collarray[index].bottom://
                PlayerRect.top = collarray[index].bottom
                side = "top"
                #
    index = PlayerRect.collidelist(collarray)   #checks if player still colliding, even after moving 
    if index == -1:
        safe[1] = True
    else:
        pass#print("need to get to safety2")
    #unimplemented system of saving previous safe spots for player to stand, when falling into pits
    if safe[0] and safe[1]:
        return PlayerRect,speed,returnType,index, side, [PlayerRect.x,PlayerRect.y,scroll]

                

    return PlayerRect,speed,returnType,index, side, False
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def redraw(PlayerRect, scroll, RectArray,speed,slack = 100):
    
    Rect = []

    #story time: in games, everything has a position on the screen, and it is imperative that the scharacter stays on the screen, but if the
    #player wants to go more than the screenś width left or right, a trick of the mind called relative position must be used instead of actually
    #moving tyhe scaracter off screen. Humans are aware and intuitive about shifting perspective, we never look from the exact same angle for
    #long, and therefore our mind, when it sees that the player makes a running animation, while the background moves at the speed you would
    #expect the player to move, it just looks like the player and camera are moving at the same speed. slower speeds in deeper backgrounds makes
    #them look further away, hence the cool depth affect of paralax.

    #if the player is to the right or left of the center of the screen, move the player and background in the opposite direction
    change = int(-1*(PlayerRect.x-WINWIDTH/2)/5)
    scroll[0] += change
    PlayerRect.x += change
    
##    change = int(-1*(PlayerRect.y)) IMPLEMENT Y SCROLL XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
##    scroll[1] += change
##    PlayerRect.y += change

    #ignore the weird name, redraws all the blocks on screen
    collision_array = []
    for surf in RectArray:#redraw all map and apply dilation and scroll
        collision_array.append(DISPLAYSURF.blit(surf[1],( (surf[0].x+scroll[0]) ,(surf[0].y+scroll[1]) )))
    return scroll, PlayerRect, collision_array


def parseInput(PlayerRect,PlayerSpeed,grounded, pressed):
    #this is another cool thing. for input there are three different ways of handling the  given input. pressing "R" and restarting the program will
    #handle differently from using the click hack to cheat and reposition yourself, will handle differently from normal key presses. therefore there
    #are three main exitTypes
    exitType = 0
    for event in pygame.event.get(): # event handling loop
        if event.type == QUIT:#graceful quit
            print("Thanks For Playing!")
            pygame.quit()
            sys.exit()
            
        elif event.type == KEYDOWN:#key presses, change a value in the dictionary "pressed"
            if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                pressed["left"] = True
                pressed["dominant"] = "left"
            elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                pressed["right"] = True
                pressed["dominant"] = "right"
            elif (event.key == K_UP or event.key == K_w):
                pressed["up"] = True#note: add coyote time and parabolic jumping
            elif (event.key == K_DOWN or event.key == K_s):
                pressed["down"] = True
                
            elif (event.key == K_r):#restarts the level
                exitType = 1
            elif (event.key == K_p):#pauses the level
                Pause()

                
        elif event.type == KEYUP:#key presses, change a value in the dictionary "pressed"
            #convoluted code to say ,"if left is released and right is pressed, make right the dominant direction"
            if (event.key == K_LEFT and PlayerRect.x>=0 or event.key == K_a and PlayerRect.x>=0):
                pressed["left"] = False
                if pressed["right"]:
                    pressed["dominant"] = "right"
                else:
                    pressed["dominant"] = "down"
            elif(event.key == K_RIGHT and PlayerRect.x<=WINWIDTH or event.key == K_d and PlayerRect.x<=WINWIDTH):
                pressed["right"] = False
                if pressed["left"]:
                    pressed["dominant"] = "left"
                else:
                    pressed["dominant"] = "down"
            elif (event.key == K_UP or event.key == K_w):
                pressed["up"] = False
            elif (event.key == K_DOWN or event.key == K_s):
                pressed["down"] = False#stand-in for interaction/crouch
                
        elif event.type == MOUSEBUTTONDOWN:#tp to click hack## remove later ## remove later ## remove later ##
            exitType = 2
            click = pygame.mouse.get_pos() 
    if exitType == 0:#default exit type
        return exitType, pressed, PlayerSpeed
    if exitType == 1:#restart exit type
        return exitType, "useless second return"
    if exitType == 2:#hack exit type
        return exitType, click
def walk(skin, pressed, speed, grounded_timer):#checks current step of walk cycle and returns logical next step. ALSO handles speed
    
    #left acceleration/deceleration
    if pressed["dominant"]=="left" and speed[0] > -12*DILATION:                  #full speed
        speed[0]= -12*DILATION
    elif pressed["dominant"]=="left" and speed[0] >= 0:                          #accelerating speed
        speed[0]-= 4*DILATION
    elif not pressed["left"] and pressed["dominant"]=="down" and speed[0] < 0:  #release deceleration
        speed[0]+= 4*DILATION
    elif not pressed["left"] and pressed["dominant"]=="right" and speed[0] < 0: #reverse acceleration
        speed[0]+= 8*DILATION
        
    #right acceleration/deceleration
    if pressed["dominant"]=="right" and speed[0] < 12*DILATION:                  #full speed
        speed[0] = 12*DILATION
    elif pressed["dominant"]=="right" and speed[0] <= 0:                         #accelerating speed
        speed[0]+= 4*DILATION
    elif not pressed["right"] and pressed["dominant"]=="down" and speed[0] > 0:  #release deceleration
        speed[0]-= 4*DILATION
    elif not pressed["right"] and pressed["dominant"]=="right" and speed[0] > 0: #reverse acceleration
        speed[0]-= 8*DILATION

    #jump handling
    if speed[1] < 32*DILATION:####
        speed[1]+=4*DILATION####
    if speed[1] > 36*DILATION:
        print("darn")
    jump = False
    if pressed["up"]:
        jump = True
    grounded_timer[1].pop()
    grounded_timer[1].insert(0,jump)
    
    if True in grounded_timer[0] and pressed["up"]:
        speed[1] = -16*DILATION
    if True in grounded_timer[1] and not pressed["up"] and speed[0] < 0:
        speed[1] = int(speed[1]/2)
    
    
    
    if pressed["left"] == True:
        if skin == 'walkl1' or skin == "idle":
            skin = 'walkl2'
        elif skin == 'walkl2':
            skin = 'walkl3'
        elif skin == 'walkl3':
            skin = 'walkl4'
            
        elif skin == 'walkl4':
            skin = 'walkl5'
        elif skin == 'walkl5':
            skin = 'walkl6'
        elif skin == 'walkl6':
            skin = 'walkl1'
        else:
            skin = 'walkl1'
    if pressed["right"] == True:
        if skin == 'walkr1' or skin == "idle":
            skin = 'walkr2'
        elif skin == 'walkr2':
            skin = 'walkr3'
        elif skin == 'walkr3':
            skin = 'walkr4'
        elif skin == 'walkr4':
            skin = 'walkr5'
        elif skin == 'walkr5':
            skin = 'walkr6'
        elif skin == 'walkr6':
            skin = 'walkr1'
        else:
            skin = 'walkr1'
    if not True in pressed.values():
        skin = 'idle'
    return skin, speed, grounded_timer
def __main__():
    
    init()          #global var setup/title screen
    Title()
    
    #local variable setup
    level = 0
    enemyarray = []
    pressed = {"left": False, "right": False, "up": False, "down": False, "dominant": "down"}
    grounded = False
    grav = 4
    health = 10
    w = [0,0]
    invincible = [False,False,False,False,False,False,False,False,False,False,False,False,False,False,False]
    PlayerSpeed = [0,0]
    SCROLL = [0,0]
    inventory = []
    enemyspawn = []
    text = None
    restart = True

    #creates level
    L = BackGround(level, IMAGEDICT, DISPLAYSURF)#create background return list of rect/image lists
    bg = L[3]
    objarray = L[4]
    RectArray = L[0]
    
    #create player, objects and levels
    skin = 'idle'
    PlayerRect = DISPLAYSURF.blit(IMAGEDICT["drey"][skin],DILATION*L[1])#create player rect
    for obj in objarray:
        obj["rect"] = DISPLAYSURF.blit(IMAGEDICT[obj["skin"][0]][obj["skin"][1]],obj["pos"])
            
    grounded_timer = [[False,False,False,False,False],[False,False,False,False,False]]
    for enemy in L[2]:#creates enemies from positions in L[2]
        enemyspawn.append([enemy[0],enemy[1]])
        enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT[enemy[2]][enemy[3]],[enemy[0],enemy[1]])
        enemyarray.append(enemy)
        
    while True: # main game loop
        #redraws background and blocks
        DISPLAYSURF.blit(IMAGEDICT[bg]["bg"],(0,0))
        SCROLL, PlayerRect, collision_array = redraw(PlayerRect,SCROLL,RectArray,PlayerSpeed)#[0]#redraws background efficiently

        #parse input
        exitType = parseInput(PlayerRect, PlayerSpeed, grounded, pressed)
        if exitType[0] == 0:#normal exit type
            pressed = exitType[1]
            skin, PlayerSpeed, grounded_timer = walk(skin, pressed, PlayerSpeed, grounded_timer)
        elif exitType[0] == 1:#restart exit type ####BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##BUGGY ##
            restart = True
        elif exitType[0] == 2:#click hack exit type
            PlayerRect.x = exitType[1][0]
            PlayerRect.y = exitType[1][1]
        else:
            print("bunked up")#oof
        
        #collision detection
        col = collisionDetect(PlayerRect,SCROLL,collision_array,PlayerSpeed,IMAGEDICT)
        PlayerRect = col[0]
        PlayerSpeed = col[1]
        if col[2] == "grounded":#grounded exit
            grounded = True
        else:#no special case exit
            grounded = False
        grounded_timer[0].pop()
        grounded_timer[0].insert(0,grounded)

        #shift invincible list with a pop and inserted False
        invincible.pop()
        invincible.insert(0,False)

        #obj handling
        counter = 0
        for obj in objarray:
            #if obj["rect"].x < SCROLL[0]+WINWIDTH and obj["rect"].x > SCROLL[0]:
                obj["rect"] = DISPLAYSURF.blit(IMAGEDICT[obj["skin"][0]][obj["skin"][1]],[obj["pos"][0]+SCROLL[0],obj["pos"][1]])
                if obj["skin"][1] == "DoorClosed" and "k" in inventory:
                    obj["skin"][1] = "DoorOpen"
                if obj["rect"].colliderect(PlayerRect):
                    if obj["skin"][1] == "sign":
                        text = obj["message"]
                    if obj["skin"][1] == "key":
                        inventory.append("k")
                        objarray.pop(counter)
                    if obj["skin"][1] == "DoorOpen" and "k" in inventory:
                        inventory.remove("k")
                        level+=1
                        restart = True
                    if obj["skin"][1] in IMAGEDICT["trap"].keys() and not True in invincible:
                        health -=1
                        if health <=0:
                            gameover("spikes")
                            restart = True
                        invincible.pop()
                        invincible.insert(0,True)
                        pressed = {"left": False, "right": False, "up": False, "down": False, "dominant": "down"}
                        PlayerSpeed = [0,0]
                counter+=1
        
        #enemy handling
        counter = 0
        for enemy in enemyarray:#moves and checks for grapple in each enemy

            if enemyspawn[counter][0] < SCROLL[0]+WINWIDTH and enemyspawn[counter][0] > SCROLL[0]:
                enemy.move(collision_array, PlayerRect,SCROLL,enemyspawn[counter])
                enemy.rect = DISPLAYSURF.blit(enemy.skin, [enemy.pos[0]+SCROLL[0],enemy.pos[1]])#moves and checks for grapple on each enemy
                col = collisionDetect(enemy.rect,SCROLL,collision_array,enemy.speed,IMAGEDICT)
                enemy.rect = col[0]
                enemy.prevpos = w
                w = enemy.pos
                enemy.pos[0] = enemy.rect.x-SCROLL[0]
                enemy.pos[1] = enemy.rect.y
                enemy.speed = col[1]
                if col[4] != None:
                    if not enemy.grav:
                        if col[4] == "top":
                            pass
                        if col[4] == "bottom":
                            enemy.speed[1] = -4
                    if col[4] == "left":
                        enemy.speed[0] = 4
                    if col[4] == "right":
                        enemy.speed[0] = -4
                if enemy.skin in IMAGEDICT["frog"].values():
                    if enemy.speed[1] < 32 and not col[2]:
                        enemy.speed[1] +=4
                if enemy.rect.colliderect(PlayerRect):#if enemy hits player
                    if not True in invincible:
                        enemy.zoom([PlayerRect.x,PlayerRect.y],pygame.display.get_surface())#zoom
                        if(enemy.grapple()):#pygame.transform.scale2x())):#if player wins grapple
                            enemyarray.pop(counter)#kill enemy
                        else:
                            health -=1
                            if health <=0:
                                gameover("enemy")
                                restart = True
                            invincible.pop()
                            invincible.insert(0,True)
                        pressed = {"left": False, "right": False, "up": False, "down": False, "dominant": "down"}
                        PlayerSpeed = [0,0]
            else:
                enemy.rect = DISPLAYSURF.blit(enemy.skin, [enemy.pos[0]+SCROLL[0],enemy.pos[1]])
            counter+=1

        if PlayerRect.y > WINHEIGHT:#checks if fallen off screen
            gameover("falling off the edge")
            restart = True

        if restart:
            L = BackGround(level, IMAGEDICT, DISPLAYSURF)
            RectArray = L[0]
            PlayerRect.x = L[1][0]
            PlayerRect.y = L[1][1]
            enemyarray = []
            bg = L[3]
            health = 10
            SCROLL = [0,0]
            objarray = L[4]
            enemyspawn = []
            for obj in objarray:
                obj["rect"] = DISPLAYSURF.blit(IMAGEDICT[obj["skin"][0]][obj["skin"][1]],obj["pos"])
            for enemy in L[2]:#creates enemies from positions in L[2]
                enemyspawn.append([enemy[0],enemy[1]])
                enemy = Enemy(FPSCLOCK,IMAGEDICT,DISPLAYSURF,IMAGEDICT[enemy[2]][enemy[3]],[enemy[0],enemy[1]])
                enemyarray.append(enemy)
            restart = False

        drawUI(health, text)
        text = None
        PlayerRect = DISPLAYSURF.blit(IMAGEDICT["drey"][skin],(PlayerRect.x,PlayerRect.y))#draw character
        pygame.display.update()#update screen
        #omnipresent sleep statement, so the computer doesn't explode.
        FPSCLOCK.tick(FPS)


##class Enemy():



__main__()
#try:
#    __main__()
#except:
#    print("Something broke, but Thanks For Playing!")
#    pygame.quit()
#    sys.exit()
    
            
