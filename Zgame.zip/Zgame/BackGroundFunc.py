import pygame
def BackGround(lvl, IMAGEDICT, DISPLAYSURF):
# LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # 
    y=0
    with open("levels.txt") as t:
        dest = False
        rectarray = []
        enemyarray = []
        objarray = []
        messagearray = []
        message = ""
        msg = False
        start = False
        stdSize = IMAGEDICT["plains"]["1"].get_width()
        for line in t:
            x=0
            if "$" in line and start == True:
                break
            if start == True:
                for chara in line:
                    offsety = 0
                    #SPECIAL CASES #SPECIAL CASES #SPECIAL CASES #SPECIAL CASES #
                    if chara == "\n":
                        break
                    if chara == "   " or chara == "n":
                        x+=1
                        continue
                    if chara == "*":
                        SPAWN = [x*stdSize,y*stdSize]
                    #ENEMIES # ENEMIES # ENEMIES # ENEMIES # ENEMIES # 
                    if chara == "I":
                        eye = [x*stdSize,y*stdSize,"eye","eyeR"]
                        enemyarray.append(eye)
                    if chara == "F":
                        eye = [x*stdSize,y*stdSize,"frog","frog1R"]
                        enemyarray.append(eye)
                    # TRAPS # OBJECTS # TRAPS # OBJECTS # TRAPS # OBJECTS # 
                    if chara == "^":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeUp"]}
                        objarray.append(spike)
                    if chara.lower() == "v":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeDown"]}
                        objarray.append(spike)
                    if chara == "<":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeLeft"]}
                        objarray.append(spike)
                    if chara == ">":
                        spike = {"pos":[x*stdSize,y*stdSize],"skin":["trap","SpikeDown"]}
                        objarray.append(spike)
                    if chara == "K":
                        key = {"pos":[x*stdSize,y*stdSize],"skin":["misc","key"]}
                        objarray.append(key)
                    if chara == "D":
                        door = {"pos":[x*stdSize,y*stdSize],"skin":["misc","DoorClosed"]}
                        objarray.append(door)
                    if chara == "S":
                        sign = {"pos":[x*stdSize,y*stdSize],"skin":["misc","sign"],"message":messagearray.pop(0)}
                        objarray.append(sign)
                    # BLOCKS # BLOCKS # BLOCKS # BLOCKS # BLOCKS # BLOCKS #
                    if chara not in IMAGEDICT[level[0]]:
                        pygame.draw.rect(DISPLAYSURF, (0,200,200),((x*stdSize),(y*stdSize),8,8))
                    else:
                        rectarray.append([DISPLAYSURF.blit(IMAGEDICT[level[0]][chara], (x*stdSize,y*stdSize)),IMAGEDICT[level[0]][chara]])
#LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # LEVEL FINDING # 
                    x+=1
                y+=1
            if "$" in line and "#" not in line:
                level = line.rpartition("$")
                if lvl == int(level[2].strip("\n")):
                    dest = True
#SIGN MAKING # SIGN MAKING # SIGN MAKING # SIGN MAKING # SIGN MAKING # SIGN MAKING # 
            if dest:
                if msg:
                    message = message+" "+line
                if "{" in line:
                    msg = True
                if "}" in line:
                    messagearray.append(message)
                    message = ""
                    msg = False
                if line == "!\n":
                    dest = False
                    start = True
        return rectarray, SPAWN, enemyarray, level[0], objarray
